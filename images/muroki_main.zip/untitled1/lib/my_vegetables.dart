import 'package:flutter/material.dart';
import 'package:shrink_sidemenu/shrink_sidemenu.dart';

class MyVegetables extends StatelessWidget {
  const MyVegetables({super.key});

  @override
  Widget build(BuildContext context) {
    return  Scaffold(
      resizeToAvoidBottomInset : false,
      appBar: AppBar(title: Text("내 작물정보", style: TextStyle(color : Colors.white, fontSize: 30, fontWeight: FontWeight.bold,height: 1.2,)), backgroundColor : Color(0xff06C09F), toolbarHeight: 80),
      body: Container(),
      bottomNavigationBar: CustomBottomNavigation(),
    );
  }
}

// 하단 네비게이션 바에 대한 옵션은 여기서.
class CustomBottomNavigation extends StatelessWidget {
  const CustomBottomNavigation({super.key});

  @override
  Widget build(BuildContext context) {
    return BottomAppBar(
      child: Container(
        height: 100,
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: [
            IconButton( icon : Icon(Icons.comment), onPressed: (){
            }, iconSize: 40, focusColor: Colors.white, hoverColor: Colors.white,),
            IconButton( icon : Icon(Icons.home), onPressed: (){}, iconSize: 40, focusColor: Colors.white, hoverColor: Colors.white,),
            InkWell(
              onTap: (){},
              child : Image.asset("images/circle_muroki.png", height: 100,),
              hoverColor: Colors.white,
            ),
            IconButton( icon : Icon(Icons.notifications), onPressed: (){}, iconSize: 40, focusColor: Colors.white, hoverColor: Colors.white,),
            IconButton( icon : Icon(Icons.settings), onPressed: (){}, iconSize: 40, focusColor: Colors.white, hoverColor: Colors.white,),
          ],
        ),
      ), color: Color(0xff06C09F),
    );
  }
}

Widget _createFolderInDrawer(String folderName) {
  return Container(
    padding: EdgeInsets.all(8.0),
    child: TextButton(onPressed: (){
    }, child: Text(folderName, style: TextStyle(fontSize: 20, fontWeight: FontWeight.w600),)),
    margin: EdgeInsets.fromLTRB(10, 8, 0, 0),);
}

