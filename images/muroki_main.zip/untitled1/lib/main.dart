import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:sliding_up_panel/sliding_up_panel.dart';
import 'package:intl/intl.dart';
import 'package:timer_builder/timer_builder.dart';
import 'package:shrink_sidemenu/shrink_sidemenu.dart';
import 'package:untitled1/my_vegetables.dart';

void main() => runApp(const MainScreenApp());

class MainScreenApp extends StatelessWidget {
  const MainScreenApp({super.key});

  @override
  Widget build(BuildContext context) {
    final GlobalKey<SideMenuState> _sideMenuKey = GlobalKey<SideMenuState>();
    String formattedDate = DateFormat('yyyy년 MM월 dd일 (E)').format(DateTime.now());
    String formattedTime = DateFormat('HH시 mm분').format(DateTime.now());
    BorderRadiusGeometry radius = BorderRadius.only(
      topLeft: Radius.circular(24.0),
      topRight: Radius.circular(24.0),
    );
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorSchemeSeed: const Color(0xff06C09F),
        useMaterial3: true,
      ),
      home: Scaffold(
        resizeToAvoidBottomInset : false,
        appBar: AppBar(title: Image(
          width : 80,
          image: AssetImage('images/wlogo.png'),
        ), centerTitle: true, backgroundColor : Color(0xff06C09F), toolbarHeight: 80),
          body : SlidingUpPanel(
            minHeight: 100,
            maxHeight: 550,
            borderRadius: radius,
            panel: Column(
              children: [
                Container(child: Image(image: AssetImage('images/grey_bar.png'), width: 50,), padding: EdgeInsets.all(10),),
                Container(
                  child: Text('오늘의 할 일',
                  style: TextStyle(
                    color : Color(0xff06C09F),
                    fontSize: 30,
                    fontWeight: FontWeight.bold,
                    height: 1.2,
                  ),),
                padding: EdgeInsets.all(10),
                margin: EdgeInsets.fromLTRB(0, 0, 0, 40),),
                Column(
                  children: [
                    TodayWater(),
                    TodayNutrition(),
                    TodaySolid(),
                  ],
                )
              ],
            ),
            body: Container(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    Container(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Text('$formattedDate',
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 20,
                            fontWeight: FontWeight.w400,
                            height: 1.2,
                          ),),
                          Container(
                            child: TimerBuilder.periodic(
                              const Duration(seconds: 1),
                              builder: (context) {
                                return Text(
                                  DateFormat('HH시 mm분').format(DateTime.now()),
                                  style: const TextStyle(
                                    fontSize: 40,
                                    fontWeight: FontWeight.bold,
                                    color: Colors.white,
                                  ),
                                );
                              },
                            ),
                          ),
                          Text('',
                          style:  TextStyle(
                            height : 0.5,
                          )),
                          Text('오늘의 할 일을 확인해봐요!',
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 20,
                            fontWeight: FontWeight.w300,
                            height : 1.2,
                          ),),
                        ],
                      ),
                    padding: EdgeInsets.all(50),),
                    Container(
                        child: Image(width: 400, image: AssetImage('images/main_muroki.png')),
                    margin: EdgeInsets.all(0),
                    padding: EdgeInsets.all(0),),
                    Container(
                    color : Color(0xff8AD6C8),
                    )
                  ],
                ),
              color: Color(0xff8AD6C8) ,),
          ),
        bottomNavigationBar: CustomBottomNavigation(),
        drawer: _createDrawer(),
      ),
    );
  }

  Widget _createDrawer() {
    return Drawer(
      child: ListView(
        children: [
          DrawerHeader(
            child:
                Container(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Image(width: 60, image: AssetImage('images/circle_muroki.png')),
                      Container(child: Text("무럭이", style: TextStyle(color: Colors.white, fontSize: 25, fontWeight: FontWeight.bold)), margin: EdgeInsets.fromLTRB(5, 0, 0, 0),),
                      Container(child: Text("muroki@gmail.com", style: TextStyle(color: Colors.white, fontSize: 14)), margin: EdgeInsets.fromLTRB(5, 0, 0, 0),)
                    ],
                  ),
                ),
            decoration: BoxDecoration(
                color: Color(0xff06C09F)
            ),
          ),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _createFolderInDrawer("무럭마켓"),
              _createFolderInDrawer("질문하기"),
              _createFolderInDrawer("내 작물정보"),
              _createFolderInDrawer("Log-out"),
            ],
          ),
        ],
      ),
    );
  }


  Widget _createFolderInDrawer(String folderName) {
    return Container(
      padding: EdgeInsets.all(8.0),
      child: TextButton(onPressed: (){
      }, child: Text(folderName, style: TextStyle(fontSize: 20, fontWeight: FontWeight.w600),)),
      margin: EdgeInsets.fromLTRB(10, 8, 0, 0),);
  }
}

class TodayWater extends StatelessWidget {
  const TodayWater({super.key});

  @override
  Widget build(BuildContext context) {
    return  Container(
              child: Row(
                children: [
                  Image(image: AssetImage('images/todaywater.png'), width : 100),
                  Container(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text('물 주기', style : TextStyle( fontSize: 24, fontWeight: FontWeight.bold,  height: 2.0, color: Colors.blueGrey.shade700)),
                        Text('상추, 케일, 당근, 고추', style : TextStyle( fontSize: 20, fontWeight: FontWeight.normal, color: Colors.grey ))
                      ],
                    ),
                  margin: EdgeInsets.fromLTRB(15, 0, 0, 0),)
                ],
              ),
              margin: EdgeInsets.all(10),padding: EdgeInsets.fromLTRB(15, 0, 0, 0),);
  }
}

class TodaySolid extends StatelessWidget {
  const TodaySolid({super.key});

  @override
  Widget build(BuildContext context) {
    String vegetables = '상추, 케일';
    return  Container(
        child: Row(
          children: [
            Image(image: AssetImage('images/todaysolid.png'), width : 100),
            Container(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('분갈이 하기', style : TextStyle( fontSize: 24, fontWeight: FontWeight.bold,  height: 2.0, color: Colors.blueGrey.shade700)),
                  Text('$vegetables', style : TextStyle( fontSize: 20, fontWeight: FontWeight.normal, color: Colors.grey ))
                ],
              ),
              margin: EdgeInsets.fromLTRB(15, 0, 0, 0),)
          ],
        ),
        margin: EdgeInsets.all(10),padding: EdgeInsets.fromLTRB(15, 0, 0, 0),);
  }
}

class TodayNutrition extends StatelessWidget {
  const TodayNutrition({super.key});

  @override
  Widget build(BuildContext context) {
    return  Container(
        child: Row(
          children: [
            Image(image: AssetImage('images/todaynutrition.png'), width : 100),
            Container(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('영양제 주기', style : TextStyle( fontSize: 24, fontWeight: FontWeight.bold,  height: 2.0, color: Colors.blueGrey.shade700)),
                  Text('방울토마토', style : TextStyle( fontSize: 20, fontWeight: FontWeight.normal, color: Colors.grey ))
                ],
              ),
              margin: EdgeInsets.fromLTRB(15, 0, 0, 0),)
          ],
        ),
        margin: EdgeInsets.all(10),padding: EdgeInsets.fromLTRB(15, 0, 0, 0),);
  }
}



// 하단 네비게이션 바에 대한 옵션은 여기서.
class CustomBottomNavigation extends StatelessWidget {
  const CustomBottomNavigation({super.key});

  @override
  Widget build(BuildContext context) {
    return BottomAppBar(
      child: Container(
        height: 100,
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: [
            IconButton( icon : Icon(Icons.comment), onPressed: (){
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => const MyVegetables()),
              );
            }, iconSize: 40, focusColor: Colors.white, hoverColor: Colors.white,),
            IconButton( icon : Icon(Icons.home), onPressed: (){
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => const MyVegetables()),
              );
            }, iconSize: 40, focusColor: Colors.white, hoverColor: Colors.white,),
            InkWell(
              onTap: (){},
                child : Image.asset("images/circle_muroki.png", height: 100,),
              hoverColor: Colors.white,
            ),
            IconButton( icon : Icon(Icons.notifications), onPressed: (){}, iconSize: 40, focusColor: Colors.white, hoverColor: Colors.white,),
            IconButton( icon : Icon(Icons.settings), onPressed: (){}, iconSize: 40, focusColor: Colors.white, hoverColor: Colors.white,),
          ],
        ),
      ), color: Color(0xff06C09F),
    );
  }
}

class ImportantInformation extends StatelessWidget {
  const ImportantInformation({super.key});

  @override
  Widget build(BuildContext context) {
    return  Container(
      child: Row(
        children: [
          Image(image: AssetImage('images/todaynutrition.png'), width : 100),
          Container(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('ㅎㅎㅇ의 역할', style : TextStyle( fontSize: 24, fontWeight: FontWeight.bold,  height: 2.0, color: Colors.blueGrey.shade700)),
                Text('글쎄요... 말로만 노력하기?', style : TextStyle( fontSize: 20, fontWeight: FontWeight.normal, color: Colors.grey ))
              ],
            ),
            margin: EdgeInsets.fromLTRB(15, 0, 0, 0),)
        ],
      ),
      margin: EdgeInsets.all(10),padding: EdgeInsets.fromLTRB(15, 0, 0, 0),);
  }
}

